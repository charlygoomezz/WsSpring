package es.upgrade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioOrdenadorConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
